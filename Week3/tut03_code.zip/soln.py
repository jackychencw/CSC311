def get_gd_delta(xy, f, learning_rate):
    """
    gradient descent update
    xy <-- xy + delta
    delta depends on the current position xy, the function f, and the learning rate
    """
    # write your update code below
    delta = -learning_rate*autograd.grad(f)(xy)
    # write your update code above
    return delta


def get_gd_delta_mom(xy, f, learning_rate, prev_delta, alpha):
    """
    gradient descent with momentum update
    xy <-- xy + delta
    delta depends on the current position xy, the function f, the learning rate, the previous delta, and alpha
    """
    # write your update code below
    delta = -learning_rate*autograd.grad(f)(xy) + alpha*prev_delta
    # write your update code above
    return delta

